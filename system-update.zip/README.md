**Prerequisites:** 

1. Clone the repository using the project's Git URL 
2. Navigate to the project directory
3. Install dependencies: `npm install`
4. Create an `.env.local` file and set the right environment variables at your server:

```
VITE_ID=your_app_id
VITE_BASE_URL=your_backend_url

Run the app: `npm run dev.`

**Publish your changes**

**Docs & Support**
[[
Documentation:(https://github.com/OmniOsApp/prime-odontologia-os)
